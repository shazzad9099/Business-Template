<?php

require_once "vendor/autoload.php";

if(isset($_POST['name'],$_POST['email'],$_POST['message'])) {
    $fields = [
        'name' => $_POST['name'],
        'email' => $_POST['email'],
        'message' => $_POST['message'],
    ];

    $mail = new PHPMailer;
    $mail->isSMTP();
    $mail->Host = "smtp.gmail.com";
    $mail->SMTPAuth = true;
    $mail->Username = "devs.srrkit@gmail.com";
    $mail->Password = "devs.srrkit007";
    $mail->SMTPSecure = "tls";
    $mail->Port = 587;

    $mail->From = "devs@srrkit.com";
    $mail->FromName = $fields['name'];
    
    $mail->addAddress("kamalsrrkit@gmail.com", "SRRKIT");

    $mail->isHTML(true);


    $mail->Subject = "Contact form submitted";
    $mail->Body = 'From: ' . $fields['name'] . ' (' . $fields['email'] . ') <p>' . $fields['message'] . '</p>';

    if ($mail->send()) {
        header('Location:success.php');
        die();
    } else {
        header('Location:unsuccessful.php');
        die();
    }

}
?>