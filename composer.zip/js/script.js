/*Skill Counter*/
    var cCounter = $('.circle-counter');
    if (cCounter.length) {
        cCounter.appear(function () {
            $(this).each(function () {
                var from = parseInt($(this).attr("data-from")),
                    to = parseInt($(this).attr("data-to")),
                    timer = 5000;
                $(this).easyPieChart({
                    barColor:'#FF7A00',
                    trackColor: '#FFF',
                    scaleColor: false,
                    animate: timer,
                    scaleLength: 0,
                    lineWidth: 10,
                    size: 210
                }).find('.percent').countTo({
                    from: from,
                    to: to,
                    speed: timer
                });
            });
        });
    }