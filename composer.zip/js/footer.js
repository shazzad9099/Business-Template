/* Credits: 
 * https://www.developphp.com/video/JavaScript/Circular-Progress-Loader-Canvas-JavaScript-Programming-Tutorial
 */
 

// (function() {
  
//   var Progress = function( element ) {
    
//     this.context = element.getContext( "2d" );
//     this.refElement = element.parentNode;
//     this.loaded = 0;
//     this.start = 4.72;
//     this.width = this.context.canvas.width;
//     this.height = this.context.canvas.height;
//     this.total = parseInt( this.refElement.dataset.percent, 10 );
//     this.timer = null;
    
//     this.diff = 0;
    
//     this.init();  
//   };
  
//   Progress.prototype = {
//     init: function() {
//       var self = this;
//       self.timer = setInterval(function() {
//         self.run(); 
//       }, 25);
//     },
//     run: function() {
//       var self = this;
      
//       self.diff = ( ( self.loaded / 100 ) * Math.PI * 2 * 10 ).toFixed( 2 );  
//       self.context.clearRect( 0, 0, self.width, self.height );
//       self.context.lineWidth = 10;
//       self.context.fillStyle = "#000";
//       self.context.strokeStyle = "orange";
//       self.context.textAlign = "center";
      
//       self.context.fillText( self.loaded + "%", self.width * .5, self.height * .5 + 2, self.width );
//       self.context.beginPath();
//       self.context.arc( 35, 35, 30, self.start, self.diff / 10 + self.start, false );
//       self.context.stroke();
      
//       if( self.loaded >= self.total ) {
//         clearInterval( self.timer );
//       }
      
//       self.loaded++;
//     }
//   };
  
//   var CircularSkillBar = function( elements ) {
//     this.bars = document.querySelectorAll( elements );
//     if( this.bars.length > 0 ) {
//       this.init();
//     } 
//   };
  
//   CircularSkillBar.prototype = {
//     init: function() {
//       this.tick = 25;
//       this.progress();
      
//     },
//     progress: function() {
//       var self = this;
//       var index = 0;
//       var firstCanvas = self.bars[0].querySelector( "canvas" );
//       var firstProg = new Progress( firstCanvas );
      
      
      
//       var timer = setInterval(function() {
//         index++;
          
//         var canvas = self.bars[index].querySelector( "canvas" );
//         var prog = new Progress( canvas );
        
//         if( index == self.bars.length ) {
//             clearInterval( timer );
//         } 
        
//       }, self.tick * 100);
        
//     }
//   };
  
//   document.addEventListener( "DOMContentLoaded", function() {
//     var circularBars = new CircularSkillBar( "#bars .bar" );
//   });
  
// })();

// $(window).load(function() {
//   $('#slider .flexslider').flexslider({
//     animation: "slide"
//   });
// });

$(window).load(function(){
  $('#slider .flexslider').flexslider({ 
    animation: "fade",
    animationSpeed: 1000,
    direction: "horizontal",
    slideshowSpeed: 2000,
    pauseOnHover: true, 
    slideshow: true,
    start: function(slider){
      $('body').removeClass('loading');
    }           
  });
});


//window.scrollReveal = new scrollReveal();

//     $('span').animate({
//     width: $('.row').width()
// }, 1000);

// function window() {
//             location.reload('');
//          }
$(function() {
  $('a[href*=#]:not([href=#])').click(function() {
    if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
      if (target.length) {
        $('html,body').animate({
          scrollTop: target.offset().top
        }, 1000);
        return false;
      }
    }
  });
});
$(document).ready(function(){
$(".scroll").click(function(event){
event.preventDefault();
var full_url = this.href;
var parts = full_url.split("#");
var trgt = parts[1];
var target_offset = $("#"+trgt).offset();
var target_top = target_offset.top - 85;
$('html, body').animate({scrollTop:target_top}, 1400);
});
});


// $(document).ready(function(){
//     $("#searchi").click(function(){
//         $("#formsearch").toggle();
//     });
// });
$("button").click(function(){
    $("#bs-example-navbar-collapse-1").slideToggle();
});

jQuery(document).ready(function($) {
  
    // Fixa navbar ao ultrapassa-lo
    var navbar = $('#navigation'),
            distance = navbar.offset().top,
        $window = $(window);

    $window.scroll(function() {
        if ($window.scrollTop() >= 500) {
            navbar.removeClass('navbar-fixed-top').addClass('navbar-fixed-top');
            $("body").css("padding-top", "0px");
        } else {
            navbar.removeClass('navbar-fixed-top');
            $("body").css("padding-top", "0px");
        }
    });
});


 /*Portfolio */


jQuery(document).ready(function() {
  
  function portfolio_quicksand() {
    
    // Setting Up Our Variables
    var $filter;
    var $container;
    var $containerClone;
    var $filterLink;
    var $filteredItems
    
    $filter = jQuery('.filter li.active a').attr('class');
    $filterLink = jQuery('.filter li a');
    $container = jQuery('ul.filterable-grid');
    $containerClone = $container.clone();
    
    $filterLink.click(function(e) 
    {
      jQuery('.filter li').removeClass('active');
      $filter = jQuery(this).attr('class').split(' ');
      
      jQuery(this).parent().addClass('active');
      
      if ($filter == 'all') {
        $filteredItems = $containerClone.find('li'); 
      }
      else {
        $filteredItems = $containerClone.find('li[data-type~=' + $filter + ']'); 
      }
      
      $container.quicksand($filteredItems, 
      {
        duration: 750,
        easing: 'swing',
        adjustHeight: 'dynamic' 
      });
          
    });
  }
  
  if(jQuery().quicksand) {
    portfolio_quicksand();  
  }
  
});



 /*Skill Counter*/

    var cCounter = $('.circle-counter');
    if (cCounter.length) {
        cCounter.appear(function () {
            $(this).each(function () {
                var from = parseInt($(this).attr("data-from")),
                    to = parseInt($(this).attr("data-to")),
                    timer = 5000;
                $(this).easyPieChart({
                    barColor:'#17C2A4',
                    trackColor: '#FFF',
                    scaleColor: false,
                    animate: timer,
                    scaleLength: 0,
                    lineWidth: 10,
                    size: 210
                }).find('.percent').countTo({
                    from: from,
                    to: to,
                    speed: timer
                });
            });
        });
    }



